﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Lab4ADO.NET
{
    public partial class cmbcolumnlist : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public cmbcolumnlist()
        {
            InitializeComponent();
        }

        private void cmbcolumnlist_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser");

            con.Open(); ds = new DataSet();               //select - For Data Retrieval              
            da = new SqlDataAdapter("select * from supplier_172322 ", con); 

            da.Fill(ds,"cust");

            grdCustomers.DataSource = ds.Tables["cust"];
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = comboBox1.Text;

        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like '" + txtcity.Text + "'";
            MessageBox.Show("City Details Displayed");
        }
    }
}
