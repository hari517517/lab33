﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RowStateLab
{
    public partial class Form1 : Form
    {
        DataTable table = new DataTable("Customers");
        DataSet dsCustomer = new DataSet();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach (DataRow drow in dsCustomer.Tables["Customers"].Rows)
            {
                if (drow.RowState == DataRowState.Added)
                {
                    MessageBox.Show(drow["CustomerId", DataRowVersion.Current].ToString() +
                    " Added ");
                }
                else
                    MessageBox.Show(drow["CustomerId"].ToString() + " " +
                    drow.RowState.ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            DataColumn C1 = new DataColumn("CustomerId", typeof(int));
            DataColumn C2 = new DataColumn("CompanyName", typeof(String));
            DataColumn C3 = new DataColumn("ContactName", typeof(String));
            //
            table.Columns.Add(C1);
            table.Columns.Add(C2);
            table.Columns.Add(C3);
            table.Constraints.Add("PK_CustomerID", C1, true);

            
            dsCustomer.Tables.Add(table);

            dsCustomer.Tables[0].BeginLoadData();
            DataRow row1 = table.NewRow();
            row1["CustomerID"] = 445;
            row1["CompanyName"] = "Capgemini";
            row1["ContactName"] = "JayaSree";
            table.Rows.Add(row1);
            dsCustomer.Tables[0].EndLoadData();
            dataGridView1.DataSource = dsCustomer.Tables[0].DefaultView;
            /*
            foreach (DataRow drow in dsCustomer.Tables["Customers"].Rows)
            {
                if (drow.RowState == DataRowState.Deleted)
                {
                    MessageBox.Show(drow["CustomerId", DataRowVersion.Original].ToString() +
                    " deleted ");
                }
                else
                    MessageBox.Show(drow["CustomerId"].ToString() + " " +
                    drow.RowState.ToString());
            }*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (DataRow drow in dsCustomer.Tables["Customers"].Rows)
            {
                if (drow.RowState == DataRowState.Detached)
                {
                    MessageBox.Show(drow["CustomerId", DataRowVersion.Current].ToString() +
                    " Canceled ");
                }
                else
                    MessageBox.Show(drow["CustomerId"].ToString() + " " +
                    drow.RowState.ToString());
            }
        }
    }
}
