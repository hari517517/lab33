﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace WPFLab1
{
    /// <summary>
    /// Interaction logic for AddPatient.xaml
    /// </summary>
    public partial class AddPatient : Window
    {
        ObservableCollection<Patient> patient = new ObservableCollection<Patient>();
        public AddPatient()
        {
            InitializeComponent();
            List<string> ItemList = new List<string>();
            string[] x = { "IN Patient", "OUT Patient" };
            ItemList.AddRange(x);
            comboBoxPatientType.DataContext = ItemList;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            //Patient patientObj = new Patient { PatientId = Convert.ToInt32(textBlockPatientId.Text), PatientName = textBlockPatientName.Text, PatientType = comboBoxPatientType.SelectedItem.ToString() };
            //patient.Add(patientObj);
            //textBlockPatientId.Text = string.Empty;
            //textBlockPatientName.Text = string.Empty;


            MessageBox.Show("Patient details added successfully");
            {
                //var submit = new Menul();
                //submit.ShowDialog();
                //this.Close();
                ViewPatientInfo objpatient = new ViewPatientInfo();
                objpatient.txtpatientId.Text = textBoxUserId.Text;
                objpatient.txbPatientName.Text = textBoxPatientName.Text;
                objpatient.txbPatienttype.Text = comboBoxPatientType.SelectedItem.ToString();
                textBoxUserId.Clear();
                textBoxPatientName.Clear();
                objpatient.Show();
                
            }
        }
    }
}
