﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLab1
{
    /// <summary>
    /// Interaction logic for Menul.xaml
    /// </summary>
    public partial class Menul : Window

    {
        public Menul()
        {
            InitializeComponent();
            
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddPatient();
            window.ShowDialog();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            var viewpat = new ViewPatientInfo();
            viewpat.ShowDialog();
            this.Close();
        }
    }
}
