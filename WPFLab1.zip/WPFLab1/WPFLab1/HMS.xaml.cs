﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFLab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
  
    public partial class MainWindow : Window
    {
        public int i, j, Counter;
        string s1;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {

            if (textBoxUserName.Text == "" && textBoxPassword.Password == "")
            {
                MessageBox.Show("User Id and Password Cannot be blank");
                textBoxUserName.Focus();
                return;
            }
            Counter = Counter + 1;
            if((Counter<3))
            {
                j = 3;
                for (int i = 0; i < j; i++)
                {
                    if (textBoxUserName.Text == "admin" && textBoxPassword.Password == "admin")
                    {
                        MessageBox.Show("Logged In Successfully");
                        {
                            var login = new Menul();
                            login.ShowDialog();
                            this.Close();
                        }
                    }
                    else
                    {
                        //int s1;
                        s1 = Convert.ToString(3 - Counter);
                    }
                }
                MessageBox.Show("User id or Password are incorrect ! You have " + s1 + "tries are left.");
            }

            
            else
            {
                MessageBox.Show("Invalid Login Details", "Error", MessageBoxButton.OK);
                Environment.Exit(0);
                textBoxUserName.Clear();
                textBoxPassword.Clear();
                textBoxUserName.Text = "";
                textBoxUserName.Focus();
            }
           
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
        void Clear()
        {
            textBoxUserName.Clear();
            textBoxPassword.Clear();
            textBoxUserName.Text = "";
            textBoxUserName.Focus();
        }
       
    }
}
