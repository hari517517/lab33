﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLab1
{
    /// <summary>
    /// Interaction logic for ViewPatientInfo.xaml
    /// </summary>
    public partial class ViewPatientInfo : Window
    {
        private ObservableCollection<Patient> patient;
        public ViewPatientInfo()
        {
            InitializeComponent();
            patient = new ObservableCollection<Patient>()
            {
                new Patient(){PatientId=1,PatientName="John"},
                 new Patient(){PatientId=2,PatientName="Sravika"},
            };
          //  lstPatientDetails.ItemsSource = patient;
            List<string> ItemList = new List<string>();
            string[] x = { };
            ItemList.AddRange(x);
            //comboBoxPatientType.DataContext = ItemList;


        }
       
    }
}
