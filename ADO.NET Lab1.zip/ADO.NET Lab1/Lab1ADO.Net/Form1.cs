﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1ADO.Net
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source = NDAMSSQL\SQLILEARN; Initial Catalog = Training_23Jan19_Mumbai; Persist Security Info = True; User ID = sqluser; Password = sqluser");
            con.Open();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader dreader = null; //The Procedure to execute 
                SqlCommand cmd = new SqlCommand("GetEmployeeById_172322", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //define procedure parameter 
                SqlParameter prm; prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);

                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txttempno.Text);

                //execute 
                dreader = cmd.ExecuteReader();

                //if employee record found
                if (dreader.Read())
                {
                    txtempname.Text = dreader["empname"].ToString();
                    txtsal.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        rdbPayroll.Checked = true;
                    else
                        rdbCompensation.Checked = true;
                }
              
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void lblemployeeno_Click(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txttempno.Text = "";
            txtempname.Text = "";
            txtsal.Text = "";
            txttempno.Focus();
        }

        //private void btnSave_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        //The Insert DML to add employee record 
        //        SqlCommand cmd = new SqlCommand("insert into employee values(@eno,@enm,@esal,@etyp)", con);

        //        //The Parameters  
        //        cmd.Parameters.Add("@eno", SqlDbType.Int);
        //        cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
        //        cmd.Parameters.Add("@esal", SqlDbType.Decimal);
        //        cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);

        //        //Assigning Values to parameters 
        //        cmd.Parameters["@eno"].Value = txttempno.Text;
        //        cmd.Parameters["@enm"].Value = txtempname.Text;
        //        cmd.Parameters["@esal"].Value = txtsal.Text;
        //        cmd.Parameters["@etyp"].Value = rdbPayroll.Checked == true ? "P" : "C";

        //        //Execute Insert .... 
        //        cmd.ExecuteNonQuery();
        //        MessageBox.Show("Employee Details Saved");
        //    }

        //    catch (SqlException sqlex)
        //    {
        //        MessageBox.Show(sqlex.Message);
        //    }
        //}

        private void txttempno_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            try
            {
                //The Insert DML to add employee record 
                SqlCommand cmd = new SqlCommand("insert into employee_172322 values(@eno,@enm,@esal,@etyp)", con);

                //The Parameters  
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);

                //Assigning Values to parameters 
                cmd.Parameters["@eno"].Value = txttempno.Text;
                cmd.Parameters["@enm"].Value = txtempname.Text;
                cmd.Parameters["@esal"].Value = txtsal.Text;
                cmd.Parameters["@etyp"].Value = rdbPayroll.Checked == true ? "P" : "C";

                //Execute Insert .... 
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }

            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int empn = int.Parse(txttempno.Text);
            DialogResult dialogResult = System.Windows.Forms.MessageBox.Show("Are you sure?", "Delete Confirmation", MessageBoxButtons.YesNo);
            if (dialogResult==DialogResult.Yes)
            {
                cmd = new SqlCommand("delete employee_172322 where empno=(@eno)", con);
               // con.Open();
                cmd.Parameters.AddWithValue("@eno",empn);
                cmd.ExecuteNonQuery();
               // con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }
        }
    }

