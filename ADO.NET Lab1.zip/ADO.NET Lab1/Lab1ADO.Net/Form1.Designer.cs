﻿namespace Lab1ADO.Net
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtempno = new System.Windows.Forms.Label();
            this.txttempno = new System.Windows.Forms.TextBox();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.lblsalary = new System.Windows.Forms.Label();
            this.txtsal = new System.Windows.Forms.TextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.grpemployeetype = new System.Windows.Forms.GroupBox();
            this.rdbCompensation = new System.Windows.Forms.RadioButton();
            this.rdbPayroll = new System.Windows.Forms.RadioButton();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblemployeename = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.grpemployeetype.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtempno
            // 
            this.txtempno.AutoSize = true;
            this.txtempno.Location = new System.Drawing.Point(70, 56);
            this.txtempno.Name = "txtempno";
            this.txtempno.Size = new System.Drawing.Size(70, 13);
            this.txtempno.TabIndex = 0;
            this.txtempno.Text = "Employee No";
            this.txtempno.Click += new System.EventHandler(this.lblemployeeno_Click);
            // 
            // txttempno
            // 
            this.txttempno.AcceptsTab = true;
            this.txttempno.Location = new System.Drawing.Point(186, 53);
            this.txttempno.Name = "txttempno";
            this.txttempno.Size = new System.Drawing.Size(100, 20);
            this.txttempno.TabIndex = 1;
            this.txttempno.TextChanged += new System.EventHandler(this.txttempno_TextChanged);
            // 
            // txtempname
            // 
            this.txtempname.Location = new System.Drawing.Point(186, 108);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(100, 20);
            this.txtempname.TabIndex = 3;
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Location = new System.Drawing.Point(73, 173);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(36, 13);
            this.lblsalary.TabIndex = 4;
            this.lblsalary.Text = "Salary";
            // 
            // txtsal
            // 
            this.txtsal.Location = new System.Drawing.Point(186, 170);
            this.txtsal.Name = "txtsal";
            this.txtsal.Size = new System.Drawing.Size(100, 20);
            this.txtsal.TabIndex = 5;
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(126, 243);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 23);
            this.btnQuery.TabIndex = 6;
            this.btnQuery.Text = "Query";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // grpemployeetype
            // 
            this.grpemployeetype.Controls.Add(this.rdbCompensation);
            this.grpemployeetype.Controls.Add(this.rdbPayroll);
            this.grpemployeetype.Location = new System.Drawing.Point(379, 53);
            this.grpemployeetype.Name = "grpemployeetype";
            this.grpemployeetype.Size = new System.Drawing.Size(188, 100);
            this.grpemployeetype.TabIndex = 7;
            this.grpemployeetype.TabStop = false;
            this.grpemployeetype.Text = "employee Type";
            // 
            // rdbCompensation
            // 
            this.rdbCompensation.AutoSize = true;
            this.rdbCompensation.Location = new System.Drawing.Point(7, 67);
            this.rdbCompensation.Name = "rdbCompensation";
            this.rdbCompensation.Size = new System.Drawing.Size(92, 17);
            this.rdbCompensation.TabIndex = 1;
            this.rdbCompensation.TabStop = true;
            this.rdbCompensation.Text = "Compensation";
            this.rdbCompensation.UseVisualStyleBackColor = true;
            // 
            // rdbPayroll
            // 
            this.rdbPayroll.AutoSize = true;
            this.rdbPayroll.Location = new System.Drawing.Point(7, 30);
            this.rdbPayroll.Name = "rdbPayroll";
            this.rdbPayroll.Size = new System.Drawing.Size(64, 17);
            this.rdbPayroll.TabIndex = 0;
            this.rdbPayroll.TabStop = true;
            this.rdbPayroll.Text = "Pay Roll";
            this.rdbPayroll.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(379, 231);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 8;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(507, 231);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click_1);
            // 
            // lblemployeename
            // 
            this.lblemployeename.AutoSize = true;
            this.lblemployeename.Location = new System.Drawing.Point(73, 108);
            this.lblemployeename.Name = "lblemployeename";
            this.lblemployeename.Size = new System.Drawing.Size(84, 13);
            this.lblemployeename.TabIndex = 2;
            this.lblemployeename.Text = "Employee Name";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(238, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.grpemployeetype);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.txtsal);
            this.Controls.Add(this.lblsalary);
            this.Controls.Add(this.txtempname);
            this.Controls.Add(this.lblemployeename);
            this.Controls.Add(this.txttempno);
            this.Controls.Add(this.txtempno);
            this.Name = "Form1";
            this.Text = "Employee Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpemployeetype.ResumeLayout(false);
            this.grpemployeetype.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtempno;
        private System.Windows.Forms.TextBox txttempno;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.Label lblsalary;
        private System.Windows.Forms.TextBox txtsal;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.GroupBox grpemployeetype;
        private System.Windows.Forms.RadioButton rdbCompensation;
        private System.Windows.Forms.RadioButton rdbPayroll;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblemployeename;
        private System.Windows.Forms.Button button1;
    }
}

